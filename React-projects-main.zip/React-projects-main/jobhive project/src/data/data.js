export const categoryData = () => {
    const category = [
        'All category', 'Accounting', 'Account Management/Customer Success',
        ' Corporate', 'Customer Service Career',
        'Data Science', 'Design', 'Editor', 'Education',
        'HR', 'IT', 'Law', 'Marketing', 'Mechanic',
        'Mental Health', 'Nurses',
        'Office Administration', 'Physical Assistant',
        'Product', 'Project Management', 'Public Relations',
        'Recruiting', 'Retail', 'Sales', 'Software Engineer',
        'UX', 'Videography', 'Writer'
    ]
    return category;
}

export const levelData = () => {
    const level = [
        'All level', 'Entry Level', 'Mid Level', 'Senior Level', 'Management', 'Internship'
    ]
    return level;
}